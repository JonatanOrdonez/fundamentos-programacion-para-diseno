const formulario = document.querySelector("#formularioCalculadora");
console.log(formulario);

formulario.addEventListener("submit", function (event) {
  event.preventDefault();

  if (!event.target["numeroA"]) {
    alert("No se encontró un input con id 'numeroA'");
    return;
  }

  if (event.target["numeroA"].type !== "number") {
    alert("El input con id 'numeroA' no es de tipo 'number'");
    return;
  }

  if (!event.target["operacion"]) {
    alert("No se encontró un select con id 'operacion'");
    return;
  }

  if (event.target["operacion"].type !== "select-one") {
    alert("El input con id 'operacion' no es de tipo 'select'");
    return;
  }

  if (!event.target["numeroB"]) {
    alert("No se encontró un input con id 'numeroB'");
    return;
  }

  if (event.target["numeroB"].type !== "number") {
    alert("El input con id 'numeroB' no es de tipo 'number'");
    return;
  }

  const numeroA = event.target["numeroA"].value;
  const numeroB = event.target["numeroB"].value;
  const operacion = event.target["operacion"].value;

  const numA = parseFloat(numeroA);
  const numB = parseFloat(numeroB);

  let resultado = 0;
  let operador = "";

  switch (operacion) {
    case "suma":
      resultado = numA + numB;
      operador = "+";
      break;
    case "resta":
      resultado = numA - numB;
      operador = "-";
      break;
    case "multiplicacion":
      resultado = numA * numB;
      operador = "x";
      break;
    case "division":
      if (numB === 0) {
        alert(`No está permitido la división por 0`);
        return;
      }
      resultado = numA / numB;
      operador = "/";
      break;
    default:
      alert(
        `El valor '${operacion}' no está permitido en las opciones del Select. Los valores permitidos son 'suma', 'resta', 'multiplicacion'`
      );
      return;
  }

  resultado = resultado.toFixed(1);

  const seccionOperaciones = document.querySelector("#seccionOperaciones");

  const operacionContenedor = document.createElement("div");
  operacionContenedor.classList.add("operacion");

  const textoNumA = document.createElement("p");
  textoNumA.classList.add("operacion--texto");
  textoNumA.innerHTML = numA;

  const textoOperador = document.createElement("p");
  textoOperador.classList.add("operacion--texto");
  textoOperador.innerHTML = operador;

  const textoNumB = document.createElement("p");
  textoNumB.classList.add("operacion--texto");
  textoNumB.innerHTML = numB;

  const textoIgual = document.createElement("p");
  textoIgual.classList.add("operacion--texto");
  textoIgual.innerHTML = "=";

  const textoResultado = document.createElement("p");
  textoResultado.classList.add("operacion--texto");
  textoResultado.innerHTML = resultado;

  operacionContenedor.appendChild(textoNumA);
  operacionContenedor.appendChild(textoOperador);
  operacionContenedor.appendChild(textoNumB);
  operacionContenedor.appendChild(textoIgual);
  operacionContenedor.appendChild(textoResultado);

  seccionOperaciones.appendChild(operacionContenedor);

  formulario.reset();
});
